#include "dialog1.h"
#include "ui_dialog1.h"
extern int recover;

QFile file("result.txt");
QFile file1("key.txt");

QFile filet("filet.txt");
QFile filea("filea.txt");

qint64 length=0;
char buffer[1024];//题目
char buffer1[1024];//答案
QString str1;//错题
QString str2;//成绩报告
QString strt,stra;//错题汇总
int aa=0,bb=0,cc=0;//总题数、错题数、总时长、平均时长、正确率
float dd=0,ee=0;

int bu=0,pau=0;


Dialog1::Dialog1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog1)
{
    ui->setupUi(this);
    this->setAttribute(Qt::WA_DeleteOnClose,1);
    ui->lcdNumber->display(20);
    timerId = startTimer(1000);
}

Dialog1::~Dialog1()
{
    delete ui;
}

void Dialog1::on_pushButton_clicked()
{
    emit sendsignal();
        this->close();
}

void Dialog1::on_pushButton_2_clicked()
{

    if(bu==1)
{   if(recover==1)
  filea.readLine(buffer1,1024);
 else
 file1.readLine(buffer1,1024);

  QString answerco=buffer1;
 QString answerau=ui->lineEdit_2->text();
  answerco = answerco.trimmed();
  answerau = answerau.trimmed();

 if(!QString::compare(answerco,answerau))
      {cc=cc+20-ui->lcdNumber->value();
   //QMessageBox::information(this, tr("结果"), tr("正确"),QMessageBox::Ok);
 ui->lineEdit_3->setText("正确");
        }
 else
      { cc=cc+20-ui->lcdNumber->value();
    // QMessageBox::information(this, tr("结果"), tr("错误"));
 ui->lineEdit_3->setText("错误");
     bb++;
     QString ti=buffer;
     ti=ti.trimmed();
         str1.append(ti);
        str1.append("  ");
        str1.append(answerco);
         str1.append("  ");
         str1.append(answerau);
         str1.append("\n");

         strt.append(ti);
         strt.append("\n");
         stra.append(answerco);
         stra.append("\n");
 }

     ui->lcdNumber->display(20);
if(recover==1)
length = filet.readLine(buffer,1024);
else
length = file.readLine(buffer,1024);

ui->lineEdit->setText(buffer);
ui->lineEdit_2->setText("");
aa++;
if(recover==1)
{
    if(filet.atEnd()&&filea.atEnd())
    {
        aa--;
        filet.close();
        filea.close();
        length=0;
        QMessageBox::information(this, tr("结束"), tr("结束"));
         ui->lineEdit->setText("");
         ui->lineEdit_2->setText("");
        ui->pushButton_2->hide();

        QFile file2("2.txt");                            //写报告
          if(!file2.open(QFile::WriteOnly|QFile::Text))
          {
              QMessageBox::warning(this,tr("Error"),tr("%1").arg(file2.error()));
              return;
          }
          dd=(float)cc/(float)aa;
          ee=(float)(aa-bb)/(float)aa;
          ee=100*ee;
           str2.sprintf("%s\n","each test report");

  str2.sprintf("%s %d\n%s %d\n%s %d\n%s %.2f\n%s %.2f%\n","total question",aa,"wrong answer ",bb,"total time",cc,"averagetime",dd,"right percentage",ee);
  file2.write(str2.toLatin1(),str2.length());
              //关闭文件
  QString sttt;
  if(ee<60)
      sttt="the outcome is very bad. please study hard!";//"本次作答情况不是很理想,请继续努力."
  else if(ee<70)
       sttt="the outcome is normal.please try your best on stduy!";//"本次作答情况一般,请继续努力,期待你更加优异的表现."
  else if(ee<90)
      sttt="the outcome is pretty good. held on!";//"本次作答情况很棒,期待你更加优异的表现."
  else
       sttt="the outcome is prefect. you are very smart!";//"本次作答情况非常优秀,请继续保持."
   file2.write(sttt.toLatin1(),sttt.length());
              file2.close();
       killTimer(this->timerId);
    }
}
else{
if(file.atEnd()&&file1.atEnd())
{
    aa--;
    file.close();
    file1.close();
    length=0;
    QMessageBox::information(this, tr("结束"),tr("结束"));
     ui->lineEdit->setText("");
     ui->lineEdit_2->setText("");
    ui->pushButton_2->hide();
   killTimer(this->timerId);

   QFile file1("1.txt");                            //写错题
   if(!file1.open(QFile::Append|QFile::Text))
   {
       QMessageBox::warning(this,tr("Error"),tr("%1").arg(file1.error()));
       return;
   }
  file1.write(str1.toLatin1(),str1.length());
       //关闭文件
       file1.close();

     QFile file2("2.txt");                            //写报告
       if(!file2.open(QFile::WriteOnly|QFile::Text))
       {
           QMessageBox::warning(this,tr("Error"),tr("%1").arg(file2.error()));
           return;
       }
       dd=(float)cc/(float)aa;
       ee=(float)(aa-bb)/(float)aa;
       ee=100*ee;
       str2.sprintf("%s\n","each test report");
        //QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
       str2.sprintf("%s %d\n%s %d\n%s %d\n%s %.2f\n%s %.2f%\n","total question",aa,"wrong answer ",bb,"total time",cc,"averagetime",dd,"right percentage",ee);
       file2.write(str2.toLatin1(),str2.length());
       QString sttt;

       if(ee<60)
           sttt="the outcome is very bad. please study hard!";//"本次作答情况不是很理想,请继续努力."
       else if(ee<70)
            sttt="the outcome is normal.please try your best on stduy!";//"本次作答情况一般,请继续努力,期待你更加优异的表现."
       else if(ee<90)
           sttt="the outcome is pretty good. held on!";//"本次作答情况很棒,期待你更加优异的表现."
       else
            sttt="the outcome is prefect. you are very smart!";//"本次作答情况非常优秀,请继续保持."
        file2.write(sttt.toLatin1(),sttt.length());
           //关闭文件
           file2.close();


     QFile filet("filet.txt");                           //写错题题目
       if(!filet.open(QFile::Append|QFile::Text))
       {
           QMessageBox::warning(this,tr("Error"),tr("%1").arg(filet.error()));
           return;
       }
      filet.write(strt.toLatin1(),strt.length());
           //关闭文件
           filet.close();

       QFile filea("filea.txt");                           //写错题答案
             if(!filea.open(QFile::Append|QFile::Text))
             {
                 QMessageBox::warning(this,tr("Error"),tr("%1").arg(filea.error()));
                 return;
             }
            filea.write(stra.toLatin1(),stra.length());
                 //关闭文件
                 filea.close();


}

}

    }

}

void Dialog1::timerEvent(QTimerEvent *event)
{
    if(length!=0)

   {

    ui->lcdNumber->display(ui->lcdNumber->value() - 1);    //时间递减
    if (ui->lcdNumber->value() == 0)                       //0s时
    {

     QMessageBox::information(this, tr("结果"), tr("超时错误"));
         bb++;
         if(recover==1){

             QString ti=buffer;
             QString answerco=buffer1;
             answerco = answerco.trimmed();
             ti=ti.trimmed();
                 str1.append(ti);
                str1.append("  ");
                str1.append(answerco);
                 str1.append("     ");
                 str1.append("\n");

             length = filet.readLine(buffer,1024);
                      ui->lineEdit->setText(buffer);
                      ui->lineEdit_2->setText("");
                      aa++;
                       filea.readLine(buffer1,1024);
         }
         else
        {

          QString ti=buffer;
          QString answerco=buffer1;
          answerco = answerco.trimmed();
          ti=ti.trimmed();
              str1.append(ti);
             str1.append("  ");
             str1.append(answerco);
              str1.append("     ");
              str1.append("\n");

              strt.append(ti);
              strt.append("\n");
              stra.append(answerco);
              stra.append("\n");

              length = file.readLine(buffer,1024);
              ui->lineEdit->setText(buffer);
              ui->lineEdit_2->setText("");
               aa++;
              file1.readLine(buffer1,1024);
         }

        ui->lcdNumber->display(20);//时间回20s
        cc=cc+20;
    }





    }


}

void Dialog1::on_pushButton_3_clicked()
{
    if(recover==1)
     {
        if(!filet.open(QFile::ReadOnly|QFile::Text))
           {
               QMessageBox::warning(this,tr("Error"),tr("error of open is %1").arg(filet.error()));
               return;
           }
           if(!filea.open(QFile::ReadOnly|QFile::Text))
           {
               QMessageBox::warning(this,tr("Error"),tr("error of open is %1").arg(filea.error()));
               return;
           }

            ui->lcdNumber->display(20);
           length = filet.readLine(buffer,1024);
    }

    else
 {   if(!file.open(QFile::ReadOnly|QFile::Text))
    {
        QMessageBox::warning(this,tr("Error"),tr("error of open is %1").arg(file.error()));
        return;
    }
    if(!file1.open(QFile::ReadOnly|QFile::Text))
    {
        QMessageBox::warning(this,tr("Error"),tr("error of open is %1").arg(file1.error()));
        return;
    }

     ui->lcdNumber->display(20);

    //读取一行数据
    length = file.readLine(buffer,1024); }

     ui->lineEdit->setText(buffer);
     ui->pushButton_3->hide();
    aa++;
    bu=1;

}
