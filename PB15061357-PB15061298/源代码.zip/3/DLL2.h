#pragma once
#include <math.h>
#include <cstdlib>
#include <ctime>

#include <stack>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

_declspec(dllexport)	bool set_len(int inf, int sup);
_declspec(dllexport)	bool set_mode(int symbol);
_declspec(dllexport)	bool set_range(int inf, int sup);
_declspec(dllexport)	bool set_row(int row);
_declspec(dllexport)	bool set_operator(bool add, bool min, bool mul, bool div, bool power);
_declspec(dllexport)	bool set_file_app(int app);
_declspec(dllexport)	bool set_path(bool symbol, bool reset, string pathe, string pathk);
_declspec(dllexport)	bool set_Ngenapp(bool symbol);
_declspec(dllexport)	bool set_PowerType(bool symbol);
_declspec(dllexport)	bool set_xi_disp(int symbol);
_declspec(dllexport)	void N_generate();
_declspec(dllexport)	void getexp(string &exps, string &keys);
_declspec(dllexport)	void getexp_i(int index, string &exps, string &str_key);
