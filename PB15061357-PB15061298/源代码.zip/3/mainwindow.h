#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QDialog>
#include<QFile>
#include<QApplication>
#include<QTextStream>
#include"dialog1.h"
#include"dialog2.h"
#include "dialog3.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_lineEdit_editingFinished();

    void on_lineEdit_2_editingFinished();
    //void timerEvent(QTimerEvent*event);
    void reshow();//这个函数用户向主界面通知关闭的消息


    void on_lineEdit_3_editingFinished();

    void on_actionstart_triggered();

    void on_actionstart_changed();

    void on_actionhistory_triggered();

    void on_action_report_triggered();

    void on_pushButton_3_clicked();

    void on_action_z_triggered();

    void on_lineEdit_4_editingFinished();

private:
    Ui::MainWindow *ui;
        int timerId;

};

#endif // MAINWINDOW_H
