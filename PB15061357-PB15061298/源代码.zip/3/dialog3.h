#ifndef DIALOG3_H
#define DIALOG3_H

#include <QDialog>
#include <QMainWindow>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include<QFile>
#include<QApplication>
#include<QTextStream>
#include<QTextCodec>
namespace Ui {
class Dialog3;
}

class Dialog3 : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog3(QWidget *parent = 0);
    ~Dialog3();
signals:
    void sendsignal();//这个函数用户向主界面通知关闭的消息
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Dialog3 *ui;
};

#endif // DIALOG3_H
