#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"DLL2.h"
#pragma comment(lib,"C:/Users/zyc11/Desktop/softpro/core/3/3/DLL2.lib")

float seti[15];
int recover;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{
    exit(0);
}

void MainWindow::reshow(){
    this->show();
}

void MainWindow::on_pushButton_clicked()
{

  // QString valueStr=ui->lineEdit_3->text();
if(ui->radioButton->isChecked())
    seti[3]=1;
else
    seti[3]=0;
if(ui->radioButton_2->isChecked())
    seti[4]=1;
else
    seti[4]=0;
if(ui->radioButton_3->isChecked())
    seti[5]=1;
else
    seti[5]=0;
if(ui->radioButton_4->isChecked())
    recover=1;
else
    recover=0;
if(ui->checkBox->isChecked())
    seti[6]=1;
else
    seti[6]=0;
if(ui->checkBox_2->isChecked())
   seti[7]=1;
else
   seti[7]=0;
if(ui->checkBox_3->isChecked())
   seti[8]=1;
else
    seti[8]=0;
if(ui->checkBox_4->isChecked())
   seti[9]=1;
else
    seti[9]=0;
if(ui->checkBox_5->isChecked())
   seti[10]=1;
else
    seti[10]=0;
if(ui->checkBox_6->isChecked())
   seti[11]=1;
else
    seti[11]=0;

/*int error=0,error1=0;
    seti[0];  //题目数
    seti[1];  //上限
    seti[12];  //下限
    seti[2];  //操作数数量
    argu.integer = seti[3];  //支持整数
    argu.fraction = seti[4]; //支持分数
    argu.decimal = seti[5];  //不支持小数
    argu.add = seti[6];      //支持加法
    argu.sub = seti[7];      //支持减法
    argu.multiply = seti[8]; //支持乘法
    argu.division = seti[9]; //支持除法
    argu.pow = seti[10];      //不支持乘方
    argu.bracktet = seti[11]; //支持括号
    error=Setting(seti[0],seti[1], argu);
  //  error=Setting(seti[0],seti[1],seti[2],seti[3],seti[4],seti[5],seti[6],seti[7],seti[8],seti[9],seti[10],seti[11]);
    error1=Generate(error);
*/
set_row(seti[0]);
set_range(seti[1],seti[12]);
int zixuan=seti[2]*2-1;
set_len(zixuan,zixuan);
int mode;
if(seti[3]==1)mode=0;
else if(seti[4]==1)mode=1;
else mode=2;
set_mode(mode);
set_operator(seti[6],seti[7],seti[8],seti[9],seti[10]);



set_path(1,1,"result.txt","key.txt");
N_generate();

QMessageBox::about(NULL, "成功","准备答题");
this->hide();
Dialog1 *dialog1=new Dialog1(this);
connect(dialog1,SIGNAL(sendsignal()),this,SLOT(reshow()));//当点击子界面时，调用主界面的reshow()函数
dialog1->show();



}

void MainWindow::on_lineEdit_editingFinished()
{
    QString valueStr=ui->lineEdit->text();
    seti[0]=valueStr.toFloat();
}

void MainWindow::on_lineEdit_2_editingFinished()
{
    QString valueStr=ui->lineEdit_2->text();
    seti[1]=valueStr.toFloat();
}



void MainWindow::on_lineEdit_3_editingFinished()
{
    QString valueStr=ui->lineEdit_3->text();
    seti[2]=valueStr.toFloat();
}

void MainWindow::on_actionstart_triggered()
{
   exit(0);

}
void MainWindow::on_actionstart_changed()
{

}

void MainWindow::on_actionhistory_triggered()
{
    this->hide();
    Dialog2 *dialog2=new Dialog2(this);
    connect(dialog2,SIGNAL(sendsignal()),this,SLOT(reshow()));//当点击子界面时，调用主界面的reshow()函数
    dialog2->show();

}

void MainWindow::on_action_report_triggered()
{
    this->hide();
    Dialog3 *dialog3=new Dialog3(this);
    connect(dialog3,SIGNAL(sendsignal()),this,SLOT(reshow()));//当点击子界面时，调用主界面的reshow()函数
    dialog3->show();
}



void MainWindow::on_pushButton_3_clicked()
{

}

void MainWindow::on_action_z_triggered()
{
    QFile file("help.txt");
    if(!file.open(QFile::ReadOnly|QFile::Text))
    {
        QMessageBox::warning(this,tr("Error"),tr("%1").arg(file.error()));
        return;
    }
    QTextCodec* codec=QTextCodec::codecForName("GBK");//静太函数codecForName设置为UTF-8编码模式默认不是这个格式的！
      QString str;
        //判断文件是否已经读到末尾了
        while(!file.atEnd()){
            char buffer[1024];

            //读取一行数据
           file.readLine(buffer,1024);
            str+=codec->toUnicode(buffer);

        }
        file.close();
    QMessageBox::about(NULL, "说明",str);//请写说明
}

void MainWindow::on_lineEdit_4_editingFinished()
{
    QString valueStr=ui->lineEdit_4->text();
    seti[12]=valueStr.toFloat();
}
