#ifndef DIALOG1_H
#define DIALOG1_H

#include <QDialog>
#include <QMainWindow>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include<QFile>
#include<QApplication>
#include<QTextStream>
#include<QTextCodec>
namespace Ui {
class Dialog1;
}

class Dialog1 : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog1(QWidget *parent = 0);
    ~Dialog1();

private:
    Ui::Dialog1 *ui;
     int timerId;
signals:
    void sendsignal();//这个函数用户向主界面通知关闭的消息
private slots:
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void timerEvent(QTimerEvent*event);
    void on_pushButton_3_clicked();
};

#endif // DIALOG1_H
