#ifndef DIALOG2_H
#define DIALOG2_H

#include <QDialog>
#include <QMainWindow>
#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include<QFile>
#include<QApplication>
#include<QTextStream>
#include<QTextCodec>
namespace Ui {
class Dialog2;
}

class Dialog2 : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog2(QWidget *parent = 0);
    ~Dialog2();
signals:
    void sendsignal();//这个函数用户向主界面通知关闭的消息

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Dialog2 *ui;
};

#endif // DIALOG2_H
