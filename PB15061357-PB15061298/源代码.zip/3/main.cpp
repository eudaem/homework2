#include "mainwindow.h"
#include <QApplication>
#include<QDebug>
//#include"Core_x64.h"
//#pragma comment(lib,"C:/Users/zyc11/Desktop/softpro/core/15/15/Core_x64.lib")
//LIBS+= -L C:/Users/zyc11/Desktop/softpro/hw2/2/untitled2/ -l www
int main(int argc, char *argv[])
{

    QApplication a(argc, argv);
    MainWindow w;
   w.show();

 return a.exec();


}
