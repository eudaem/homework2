#include "dialog2.h"
#include "ui_dialog2.h"

Dialog2::Dialog2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog2)
{
    ui->setupUi(this);

    this->setAttribute(Qt::WA_DeleteOnClose,1);
}

Dialog2::~Dialog2()
{
    delete ui;
}

void Dialog2::on_pushButton_clicked()
{
    emit sendsignal();
        this->close();
}

void Dialog2::on_pushButton_2_clicked()
{
    QFile file("1.txt");
    if(!file.open(QFile::ReadOnly|QFile::Text))
    {
        QMessageBox::warning(this,tr("Error"),tr("%1").arg(file.error()));
        return;
    }
    QTextCodec* codec=QTextCodec::codecForName("GBK");//静太函数codecForName设置为UTF-8编码模式默认不是这个格式的！
      QString str;
        //判断文件是否已经读到末尾了
        while(!file.atEnd()){
            char buffer[1024];

            //读取一行数据
           file.readLine(buffer,1024);
            str+=codec->toUnicode(buffer);

        }
         ui->textEdit->setText(str);
        //关闭文件
        file.close();
}
